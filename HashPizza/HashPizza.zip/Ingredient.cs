﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashPizza
{
    public enum Ingredient : byte
    {
        Tomato,
        Mushroom
    }
}
